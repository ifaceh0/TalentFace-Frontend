import api from '../lib/api';
import type {
  DeckJob,
  DeckCandidate,
  SwipePayload,
  RecruiterSwipePayload,
  SwipeResponse,
  MatchDoc,
  Paginated,
} from '../types/swipe.types';

// ─── Candidate: get ranked job deck ──────────────────────────────────────────────

export const getJobDeck = async (
  page = 1,
  limit = 20,
): Promise<Paginated<DeckJob>> => {
  const { data } = await api.get('/swipe/deck', { params: { page, limit } });
  return data.data;
};

// ─── Candidate: swipe on a job ───────────────────────────────────────────────────

export const swipeJob = async (payload: SwipePayload): Promise<SwipeResponse> => {
  const { data } = await api.post('/swipe', payload);
  return data.data;
};

// ─── Candidate: undo the most recent swipe (real, server-side rewind) ───────

export const undoSwipe = async (): Promise<{ jobId: string; direction: 'left' | 'right' }> => {
  const { data } = await api.delete('/swipe/last');
  return data.data;
};

// ─── Recruiter: undo the most recent swipe for a job ─────────────────────────

export const undoRecruiterSwipe = async (
  jobId: string,
  ): Promise<{ candidateId: string; direction: 'left' | 'right' }> => {
    const { data } = await api.delete('/swipe/recruiter/last', { params: { jobId } });
    return data.data;
};

// ─── Candidate: get swipe history ────────────────────────────────────────────────

export const getSwipeHistory = async (
  direction?: 'left' | 'right',
  page = 1,
  limit = 20,
) => {
  const { data } = await api.get('/swipe/history', {
    params: { direction, page, limit },
  });
  return data.data;
};

// ─── Recruiter: get ranked candidate deck for a job ───────────────────────────

export const getCandidateDeck = async (
  jobId: string,
  page = 1,
  limit = 20,
): Promise<Paginated<DeckCandidate>> => {
  const { data } = await api.get('/swipe/recruiter/deck', {
    params: { jobId, page, limit },
  });
  return data.data;
};

// ─── Recruiter: swipe on a candidate ─────────────────────────────────────────

export const swipeCandidate = async (
  payload: RecruiterSwipePayload,
): Promise<SwipeResponse> => {
  const { data } = await api.post('/swipe/recruiter', payload);
  return data.data;
};

// ─── Candidate: get own matches ──────────────────────────────────────────────────

export const getCandidateMatches = async (
  status?: 'pending' | 'accepted' | 'rejected',
  page = 1,
  limit = 20,
): Promise<Paginated<MatchDoc>> => {
  const { data } = await api.get('/matches', { params: { status, page, limit } });
  return data.data;
};

// ─── Recruiter: get matches on their jobs ─────────────────────────────────────

export const getRecruiterMatches = async (
  jobId?: string,
  status?: 'pending' | 'accepted' | 'rejected',
  page = 1,
  limit = 20,
): Promise<Paginated<MatchDoc>> => {
  const { data } = await api.get('/matches/recruiter', {
    params: { jobId, status, page, limit },
  });
  return data.data;
};

// ─── Recruiter: accept / reject a match ──────────────────────────────────────

export const updateMatchStatus = async (
  matchId: string,
  status: 'accepted' | 'rejected',
): Promise<MatchDoc> => {
  const { data } = await api.patch(`/matches/${matchId}/status`, { status });
  return data.data.match;
};

// import api from '../lib/api';
// import type {
//   DeckJob,
//   DeckCandidate,
//   SwipePayload,
//   RecruiterSwipePayload,
//   SwipeResponse,
//   MatchDoc,
//   Paginated,
// } from '../types/swipe.types';

// // ─── Joinee: get ranked job deck ──────────────────────────────────────────────

// export const getJobDeck = async (
//   page = 1,
//   limit = 20,
// ): Promise<Paginated<DeckJob>> => {
//   const { data } = await api.get('/swipe/deck', { params: { page, limit } });
//   return data.data;
// };

// // ─── Joinee: swipe on a job ───────────────────────────────────────────────────

// export const swipeJob = async (payload: SwipePayload): Promise<SwipeResponse> => {
//   const { data } = await api.post('/swipe', payload);
//   return data.data;
// };

// // ─── Joinee: get swipe history ────────────────────────────────────────────────

// export const getSwipeHistory = async (
//   direction?: 'left' | 'right',
//   page = 1,
//   limit = 20,
// ) => {
//   const { data } = await api.get('/swipe/history', {
//     params: { direction, page, limit },
//   });
//   return data.data;
// };

// // ─── Recruiter: get ranked candidate deck for a job ───────────────────────────

// export const getCandidateDeck = async (
//   jobId: string,
//   page = 1,
//   limit = 20,
// ): Promise<Paginated<DeckCandidate>> => {
//   const { data } = await api.get('/swipe/recruiter/deck', {
//     params: { jobId, page, limit },
//   });
//   return data.data;
// };

// // ─── Recruiter: swipe on a candidate ─────────────────────────────────────────

// export const swipeCandidate = async (
//   payload: RecruiterSwipePayload,
// ): Promise<SwipeResponse> => {
//   const { data } = await api.post('/swipe/recruiter', payload);
//   return data.data;
// };

// // ─── Joinee: get own matches ──────────────────────────────────────────────────

// export const getJoineeMatches = async (
//   status?: 'pending' | 'accepted' | 'rejected',
//   page = 1,
//   limit = 20,
// ): Promise<Paginated<MatchDoc>> => {
//   const { data } = await api.get('/matches', { params: { status, page, limit } });
//   return data.data;
// };

// // ─── Recruiter: get matches on their jobs ─────────────────────────────────────

// export const getRecruiterMatches = async (
//   jobId?: string,
//   status?: 'pending' | 'accepted' | 'rejected',
//   page = 1,
//   limit = 20,
// ): Promise<Paginated<MatchDoc>> => {
//   const { data } = await api.get('/matches/recruiter', {
//     params: { jobId, status, page, limit },
//   });
//   return data.data;
// };

// // ─── Recruiter: accept / reject a match ──────────────────────────────────────

// export const updateMatchStatus = async (
//   matchId: string,
//   status: 'accepted' | 'rejected',
// ): Promise<MatchDoc> => {
//   const { data } = await api.patch(`/matches/${matchId}/status`, { status });
//   return data.data.match;
// };